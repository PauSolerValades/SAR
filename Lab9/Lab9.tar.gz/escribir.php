<?php
    $nombre = trim($_POST['userr']);
    $mail = trim($_POST['email' ]);
    $bool = "no";
    if(isset($_POST['checkbox'])){
        $bool = "si";
    }
    $comentario = trim($_POST['conentario']);
    $date = getdate();
    $fecha = "" . $date['year'] . "/"  . $date['mon'] . "/" . $date['mday'];
    
    $visitas = simplexml_load_file('libro_visitas.xml'); // Cargamos el XML al que queremos acceder

    $nuevo = $visitas->addChild('visita'); //Creamos una visita que es la que luego tendra dentro cada uno de los parametros de cada comentario
    $nuevo->addChild('fecha',$fecha);
    $nuevo->addChild('nombre',$nombre);
    $nuevo->addChild('comentario',$comentario);
    $nuevo->addChild('email',$mail);
    $nuevo->addChild('mostrar', $bool);
    
    $visita_actual = $visitas['ult_id'];

    if(isset($visita_actual)){
        $visita_actual++;
    }else{
        $visita_actual = 1;
    }

    $nuevo->addChild('id', $visita_actual);
    $visitas['ult_id']= $visita_actual;

    $visitas->asXML('libro_visitas.xml');
    header ("Location: http://192.168.216.128/modelo.html");

?>  